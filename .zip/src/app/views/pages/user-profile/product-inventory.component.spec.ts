import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { UserProfileComponent } from './product-inventory.component';

describe('Product-UserProfileComponent', () => {
  let component: UserProfileComponent;
  let fixture: ComponentFixture<UserProfileComponent>;
  
});
export class UserProfileComponent implements OnInit {  

}