import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Component} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LocalStoreService } from 'src/app/shared/services/local-store.service';



@Component({
  selector: 'app-supplier',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './supplier.component.html',
  styleUrl: './supplier.component.scss'
})

export class SupplierComponent {
  

  constructor(
   
    private model : NgbModal,
    private LocalStoreService: LocalStoreService,



  ) {


  }
  dialogref: any;
  userType: string | null = null;

  
  
  createvendorpopup(vendorcreatepage) {

    this.dialogref = this.model.open(vendorcreatepage,{
      // fullscreen : "md"
      size : "xl"
    })
}

closedialog() {
  this.dialogref.close()
}
formData = {
  mobile: '',
  email: '',
  address: '',
  state: '',
  pincode: '',
  panNo: '',
  gstNo: ''
};

create_supplier() {
  console.log('Form Data:', this.formData);

  this.LocalStoreService.create_supplier(this.formData).subscribe(data => {
    console.log("registered data: ", data);

    this.dialogref.close()
  })
}

}