import { Injectable } from '@angular/core';
import { map, switchMap } from 'rxjs/operators';
import { Router } from "@angular/router";
import { environment } from 'src/environments/environment';

import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LocalStoreService {

  private ls = window.localStorage;
  constructor(private router: Router, private http: HttpClient) { }


  public setItem(key, value) {
    value = JSON.stringify(value);
    this.ls.setItem(key, value);
    return true;
  }

  public getItem(key) {
    const value = this.ls.getItem(key);
    try {
      return JSON.parse(value);
    } catch (e) {
      // console.log(e)
      return null;
    }
  }
  public clear() {
    this.ls.clear();
  }
  

  
  create_supplier( formData) {
    let branchId = localStorage.getItem('loginbranchid');
    let companyid = localStorage.getItem("logincompanyid")

    return this.http.post<any>(`${environment.apiUrl}/supllier/addsupplier`, { formData : formData})
      .pipe(map(response => {
        return response
      }))
  }
}
