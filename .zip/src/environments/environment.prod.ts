// export const environment = {
//   production: true
// };

export const environment = {
  production: true,
  apiUrl: 'https://doctorxx.appzcrm.com/api/clinic/login',  
};